<?php

//--Select database untuk login/
if (isset($_POST['login'])) {
    $nim = htmlspecialchars($_POST['nim']);
    $pw = htmlspecialchars($_POST['password']);
    $query = "SELECT * FROM users WHERE username='{$nim}'";
    $res = mysqli_query($db, $query);
    if (mysqli_affected_rows($db) == 1) {
        $result = mysqli_fetch_assoc($res);
        if (md5($pw) == $result['password']) {
            $adm['adm'] = $result;
            $_SESSION['data'] = $adm;
            echo "<script>
                window.location.href = 'admin/index.php'
            </script>";
            die();
        }
    }
    if ($nim == $pw) {
        $query = "SELECT * FROM mahasiswa WHERE nim = {$nim}";
        $res = mysqli_query($db, $query);
        if ($res->num_rows == 1) {
            $query = "SELECT * FROM vote WHERE nim = {$nim}";
            if (mysqli_query($db, $query)->num_rows == 0) {
                $mhs['mhs'] = mysqli_fetch_object($res);
                $_SESSION['data'] = $mhs;
                header('Location: ?vote=kuy');
            } else {
                $_SESSION['pesan'] = 'Maaf, Kamu sudah menggunakan hak pilihmu :)';
            }
        } else {
            $_SESSION['pesan'] = 'NIM Tidak Terdaftar';
        }
    } else {
        $_SESSION['pesan'] = 'NIM dan Password tidak sama';
    }
}
?>
<style>
    body {
        background-image: url(assets/img/2.jpg);
        background-repeat: no-repeat;
        background-size: cover
    }
</style>
<form class="form-signin" method="POST">
    <img class="mb-4" src="assets/img/logo.png" alt="" width="72" height="72">
    <h1 class="h3 mb-3 font-weight-normal">Masukkan NIM Kamu !</h1>
    <label for="NIM" class="sr-only">NIM</label>
    <input name="nim" type="nim" id="NIM" class="form-control" placeholder="NIM" required autofocus>
    <label for="inputPassword" class="sr-only">Password</label>
    <input name="password" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
    <button class="btn btn-lg btn-primary btn-block" type="submit" name="login">Masuk</button>
</form>
<?php if (@$_SESSION['pesan'] != null) : ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $_SESSION['pesan'] ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif;
unset($_SESSION['pesan']) ?>